package com.fanniemae.cfmt.techimmersion2.models;

import java.util.Date;

import javax.annotation.Generated;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="address")
public class Todo {
	@Id
	@Generated(value = { "street" })
	private String id;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	@NotBlank
	@Size(max=250)
	//@Indexed(unique=true)
	private String street;
	private String city;
	private String zip;
	private String state;
	private Integer baths;
	private Integer beds;
	private Double sqFt;
	private String type;
	private Date saleDate;
	private Double price;
	private Double latitude;
	private Double longtitude;
	
	
	public Todo() {
		super();
	}
	
/*
    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}*/


	public String getStreet() {
		return street;
	}


	public void setStreet(String street) {
		this.street = street;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getZip() {
		return zip;
	}


	public void setZip(String zip) {
		this.zip = zip;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public Integer getBaths() {
		return baths;
	}


	public void setBaths(Integer baths) {
		this.baths = baths;
	}


	public Integer getBeds() {
		return beds;
	}


	public void setBeds(Integer beds) {
		this.beds = beds;
	}


	public Double getSqFt() {
		return sqFt;
	}


	public void setSqFt(Double sqFt) {
		this.sqFt = sqFt;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public Date getSaleDate() {
		return saleDate;
	}


	public void setSaleDate(Date saleDate) {
		this.saleDate = saleDate;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Double getLatitude() {
		return latitude;
	}


	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}


	public Double getLongtitude() {
		return longtitude;
	}


	public void setLongtitude(Double longtitude) {
		this.longtitude = longtitude;
	}


}
