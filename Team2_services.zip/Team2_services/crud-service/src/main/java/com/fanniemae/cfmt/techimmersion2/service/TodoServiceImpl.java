package com.fanniemae.cfmt.techimmersion2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fanniemae.cfmt.techimmersion2.models.Todo;
import com.fanniemae.cfmt.techimmersion2.repositories.TodoRepository;

@Service
public class TodoServiceImpl implements TodoService {
	
	@Autowired
	TodoRepository todoRepository;
	
//	@Autowired
//	S3UploadUtil s3Util;

	public List<Todo> getAllTodos() {
		return todoRepository.findAll();
	}

	public Todo createTodo(Todo todo) {
		//NewHomeEventHandler.logEvent();
		S3UploadUtil.sendEvent(todo.getCity() + todo.getZip() + todo.getState());
		return todoRepository.save(todo);
	}

	public Todo getTodoById(String id) {
		return  todoRepository.findOne(id);
	}
	
	public Todo updateTodo(Todo todo, String id) {
		Todo todoData = this.getTodoById(id);
		if(todoData == null) {
			return null;
		}
		//todoData.setTitle(todo.getTitle());
		//todoData.setCompleted(todo.getCompleted());
		Todo updatedTodo = todoRepository.save(todoData);
		return updatedTodo;
	}
	
	public void deleteTodo(String id) {
		//todoRepository.delete(this.getTodoById(id));
		todoRepository.delete(id);
	}
}
