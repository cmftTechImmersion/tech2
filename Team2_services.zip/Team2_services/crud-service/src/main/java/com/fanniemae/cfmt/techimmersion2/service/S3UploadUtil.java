package com.fanniemae.cfmt.techimmersion2.service;

import java.io.File;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;

public class S3UploadUtil {

	private static String bucketName = "newhomebucket";
	private static String keyName = "AKIAJVL4JOLGUZG6PPYA";
	private static String uploadFileName = "NewHomeEvent_";

	public static void sendEvent(String suffix) {
		System.out.println("start Uploading a new object to S3 from a file\n");
		AWSCredentials credentials = new BasicAWSCredentials("AKIAJVL4JOLGUZG6PPYA",
				"sm0HvSke0YY+zvzEUdhADgYLnhv7DC3UymJBONzd");
		AmazonS3 s3Client = new AmazonS3Client(credentials);
		

		try {
			System.out.println("Uploading a new object to S3 from a file\n");
			File file = File.createTempFile(uploadFileName + suffix, ".txt");
			
			s3Client.putObject(new PutObjectRequest(bucketName, uploadFileName + suffix + ".txt", file));
			// uploadDocument(uploadFileName + suffix + ".txt",file);

		} catch (AmazonServiceException ase) {
			ase.printStackTrace();
			System.out.println("Caught an AmazonServiceException, which " + "means your request made it "
					+ "to Amazon S3, but was rejected with an error response" + " for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			ace.printStackTrace();
			System.out.println("Caught an AmazonClientException, which " + "means the client encountered "
					+ "an internal error while trying to " + "communicate with S3, "
					+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	public static void uploadDocument(String keyOrSoCalledPath, File fileToBeUploaded) throws Exception {

		AmazonS3 s3 = getS3Object();
		PutObjectResult putObjectResult = s3
				.putObject(new PutObjectRequest(bucketName, keyOrSoCalledPath, fileToBeUploaded));

		// PutObjectResults can give you different things.
		// Example - version number of a document.
		putObjectResult.getVersionId();

	}

	private static final AmazonS3 getS3Object() {
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).build();

		return s3Client;
	}

	public static void main(String args[]) {
		sendEvent("222");
	}

}