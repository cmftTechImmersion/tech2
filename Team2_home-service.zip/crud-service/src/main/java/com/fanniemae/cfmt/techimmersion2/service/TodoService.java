package com.fanniemae.cfmt.techimmersion2.service;

import java.util.List;

import com.fanniemae.cfmt.techimmersion2.models.Todo;

public interface TodoService {
	
	public List<Todo> getAllTodos();
	
	public Todo getTodoById(String id);
	
	public Todo createTodo(Todo todo);
	
	public void deleteTodo(String id);
	
	public Todo updateTodo(Todo todo, String id);

}
