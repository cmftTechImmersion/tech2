package com.fanniemae.cfmt.techimmersion2.service;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.Table;

public class NewHomeEventHandler {

	static AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	static DynamoDB dynamoDB = new DynamoDB(client);
	static String tableName = "HomeEvent";
	static int i = 1;

	public NewHomeEventHandler() {
	}

	
	public static  String logEvent() {

		Table table = dynamoDB.getTable(tableName);
		try {
			
			System.out.println("Adding data to " + tableName);
			Item item = new Item().withPrimaryKey("ID", String.valueOf(i)).withString("Name", "New Home");
			table.putItem(item);
			i++;
		} catch (Exception e) {
			System.err.println("Failed to create item in " + tableName);
			System.err.println(e.getMessage());
		}
		return null;
	}
}